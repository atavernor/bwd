
if(!Date.now)
Date.now=function(){return new Date().getTime();};(function(){'use strict';var vendors=['webkit','moz'];for(var i=0;i<vendors.length&&!window.requestAnimationFrame;++i){var vp=vendors[i];window.requestAnimationFrame=window[vp+'RequestAnimationFrame'];window.cancelAnimationFrame=(window[vp+'CancelAnimationFrame']||window[vp+'CancelRequestAnimationFrame']);}
if(/iP(ad|hone|od).*OS 6/.test(window.navigator.userAgent)||!window.requestAnimationFrame||!window.cancelAnimationFrame){var lastTime=0;window.requestAnimationFrame=function(callback){var now=Date.now();var nextTime=Math.max(lastTime+16,now);return setTimeout(function(){callback(lastTime=nextTime);},nextTime-now);};window.cancelAnimationFrame=clearTimeout;}}());var scrollmate=(function($)
{var _this={};var $document=$(document);var $window=$(window);_this.body_height=0;_this.viewport_height=0;_this.viewport_top=0;_this.viewport_bottom=0;_this.viewport_top_previous=-1;_this.elements=[];_this.elements_in_view=[];_this.onetime=[];_this.done_once=[];_this.property_defaults={'opacity':1,'translatex':0,'translatey':0,'translatez':0,'rotatex':0,'rotatey':0,'rotatez':0,'scale':1,'scalex':1,'scaley':1,'scalez':1,'onetime':false,'hideafter':false,'inertia':'ease','inertiatime':650,'delay':0,};_this.scrollmate_selector='.scrollmate';_this.animatesm_selector='.animate-sm';_this.update_interval=10;_this.easing_functions={'linear':function(x)
{return x;},'easeout':function(x)
{return x*x*x;},'easein':function(x)
{x=1-x;return 1-(x*x*x);},'easeinout':function(x)
{if(x<0.5)
{return(4*x*x*x);}
else
{x=1-x;return 1-(4*x*x*x);}}};_this.init_events=['load','DOMContentLoaded','page:load','page:change'];_this.init_if=function(){return true;}
_this.init=function()
{if(!_this.init_if())return false;_this.init_elements();_this.find_only_once_elements();_this.on_resize();$window.on('resize orientationchange',function(){_this.on_resize();});$window.on('load',function(){setTimeout(function(){_this.on_resize();},100)});setInterval(_this.update,_this.update_interval);return true;}
_this.init_elements=function()
{$(_this.scrollmate_selector).each(function()
{var element={};element.element=$(this);var effects=[];$(this).find(_this.animatesm_selector).addBack(_this.animatesm_selector).each(function()
{var effect={};effect.element=$(this);effect.direc=effect.element.data('direc');effect.when=effect.element.data('when');effect.from=effect.element.data('from');effect.to=effect.element.data('to');effect.onetime=effect.element.data('onetime');effect.hideafter=effect.element.data('hideafter');effect.inertia=effect.element.data('inertia');effect.inertiatime=effect.element.data('inertiatime');effect.delay=effect.element.data('delay');effect.isFresh=true;if(effect.element.is('[data-crop]'))
{effect.crop=effect.element.data('crop');}
else
{effect.crop=true;}
if(effect.element.is('[data-easing]'))
{effect.easing=_this.easing_functions[effect.element.data('easing')]}
else
{effect.easing=_this.easing_functions['easeout'];}
var properties={};if(effect.element.is('[data-opacity]'))properties.opacity=effect.element.data('opacity');if(effect.element.is('[data-translatex]'))properties.translatex=effect.element.data('translatex');if(effect.element.is('[data-translatey]'))properties.translatey=effect.element.data('translatey');if(effect.element.is('[data-translatez]'))properties.translatez=effect.element.data('translatez');if(effect.element.is('[data-rotatex]'))properties.rotatex=effect.element.data('rotatex');if(effect.element.is('[data-rotatey]'))properties.rotatey=effect.element.data('rotatey');if(effect.element.is('[data-rotatez]'))properties.rotatez=effect.element.data('rotatez');if(effect.element.is('[data-scale]'))properties.scale=effect.element.data('scale');if(effect.element.is('[data-scalex]'))properties.scalex=effect.element.data('scalex');if(effect.element.is('[data-scaley]'))properties.scaley=effect.element.data('scaley');if(effect.element.is('[data-scalez]'))properties.scalez=effect.element.data('scalez');if(effect.element.is('[data-inertiatime]'))properties.inertiatime=effect.element.data('inertiatime');if(effect.element.is('[data-inertia]'))properties.inertia=effect.element.data('inertia');if(effect.element.is('[data-delay]'))properties.delay=effect.element.data('delay');effect.properties=properties;effects.push(effect);if(effect.direc=='on-exit'){setTimeout(function(){effect.element.removeClass('is-fresh');effect.isFresh=false;effect.element.css({'transition':'transform '+effect.inertiatime+'ms '+effect.delay+'ms '+effect.inertia+', opacity '+effect.inertiatime+'ms '+effect.delay+'ms '+effect.inertia});},effect.inertiatime);}});element.effects=effects;_this.elements.push(element);});}
_this.update=function()
{window.requestAnimationFrame(function()
{_this.update_viewport_position();if(_this.viewport_top_previous!=_this.viewport_top)
{_this.update_elements_in_view();_this.animate();}
_this.viewport_top_previous=_this.viewport_top;});}
_this.animate=function()
{var elements_in_view_length=_this.elements_in_view.length;for(var i=0;i<elements_in_view_length;i++)
{var element=_this.elements_in_view[i];var effects_length=element.effects.length;for(var e=0;e<effects_length;e++)
{var effect=element.effects[e];switch(effect.when)
{case'view':case'span':var start=element.top-_this.viewport_height;var end=element.bottom;break;case'exit':var start=element.bottom-_this.viewport_height;var end=element.bottom;break;default:var start=element.top-_this.viewport_height;var end=element.top;break;}
if(effect.crop)
{if(start<0)start=0;if(end>(_this.body_height-_this.viewport_height))end=_this.body_height-_this.viewport_height;}
var scroll=(_this.viewport_top-start)/(end-start);var from=effect['from'];var to=effect['to'];var length=to-from;var scroll_relative=(scroll-from)/length;var scroll_eased=effect.easing(scroll_relative);var opacity=_this.animate_value(scroll,scroll_eased,from,to,effect,'opacity');var translatey=_this.animate_value(scroll,scroll_eased,from,to,effect,'translatey');var translatex=_this.animate_value(scroll,scroll_eased,from,to,effect,'translatex');var translatez=_this.animate_value(scroll,scroll_eased,from,to,effect,'translatez');var rotatex=_this.animate_value(scroll,scroll_eased,from,to,effect,'rotatex');var rotatey=_this.animate_value(scroll,scroll_eased,from,to,effect,'rotatey');var rotatez=_this.animate_value(scroll,scroll_eased,from,to,effect,'rotatez');var scale=_this.animate_value(scroll,scroll_eased,from,to,effect,'scale');var scalex=_this.animate_value(scroll,scroll_eased,from,to,effect,'scalex');var scaley=_this.animate_value(scroll,scroll_eased,from,to,effect,'scaley');var scalez=_this.animate_value(scroll,scroll_eased,from,to,effect,'scalez');if('scale'in effect.properties)
{scalex=scale;scaley=scale;scalez=scale;}
effect.element.css({'will-change':'transform, opacity','opacity':opacity,'transform':'translate3d( '+translatex+', '+translatey+', '+translatez+') rotateX( '+rotatex+') rotateY( '+rotatey+') rotateZ( '+rotatez+') scale3d( '+scalex+' , '+scaley+' , '+scalez+' )'});if(effect.isFresh){effect.isFresh=false;effect.element.removeClass('is-fresh');}else{effect.element.css({'transition':'transform '+effect.inertiatime+'ms '+effect.delay+'ms '+effect.inertia+', opacity '+effect.inertiatime+'ms '+effect.delay+'ms '+effect.inertia});}}}}
_this.animate_value=function(scroll,scroll_eased,from,to,effect,property)
{var value_default=_this.property_defaults[property];if(!(property in effect.properties))return value_default;var value_target=effect.properties[property];var forwards=(to>from)?true:false;var percentages=(property.indexOf('translate')>=0&&typeof value_target=='string'&&value_target.charAt(value_target.length-1)=='%');var px=(property.indexOf('translate')>=0&&typeof value_target=='string'&&value_target.substr(value_target.length-2)=='px');var vw=(property.indexOf('translate')>=0&&typeof value_target=='string'&&value_target.substr(value_target.length-2)=='vw');var vh=(property.indexOf('translate')>=0&&typeof value_target=='string'&&value_target.substr(value_target.length-2)=='vh');var translate_unit='px';if(px){value_target=parseFloat(value_target.slice(0,-2),10);translate_unit='px';}
if(percentages){value_target=parseFloat(value_target.slice(0,-1),10);translate_unit='%';}
if(vw){value_target=parseFloat(value_target.slice(0,-2),10);translate_unit='vw';}
if(vh){value_target=parseFloat(value_target.slice(0,-2),10);translate_unit='vh';}
var value_default_bnd,value_target_bnd;switch(property)
{case'opacity':value_default_bnd=value_default.toFixed(2);value_target_bnd=value_target;break;case'translatex':value_default_bnd=value_default.toFixed(2)+translate_unit;value_target_bnd=value_target.toFixed(2)+translate_unit;break;case'translatey':value_default_bnd=value_default.toFixed(2)+translate_unit;value_target_bnd=value_target.toFixed(2)+translate_unit;break;case'translatez':value_default_bnd=value_default.toFixed(2)+translate_unit;value_target_bnd=value_target.toFixed(2)+translate_unit;break;case'rotatex':value_default_bnd=value_default.toFixed(1)+'deg';value_target_bnd=value_target+'deg';break;case'rotatey':value_default_bnd=value_default.toFixed(1)+'deg';value_target_bnd=value_target+'deg';break;case'rotatez':value_default_bnd=value_default.toFixed(1)+'deg';value_target_bnd=value_target+'deg';break;case'scale':value_default_bnd=value_default.toFixed(3);value_target_bnd=value_target;break;default:break;}
if(scroll<from&&forwards){return value_default_bnd;}
if(scroll>to&&forwards){return value_target_bnd;}
if(scroll>from&&!forwards){return value_default_bnd;}
if(scroll<to&&!forwards){return value_target_bnd;}
var new_value=value_default+(scroll_eased*(value_target-value_default));switch(property)
{case'opacity':new_value=new_value.toFixed(2);break;case'translatex':new_value=new_value.toFixed(2)+translate_unit;break;case'translatey':new_value=new_value.toFixed(2)+translate_unit;break;case'translatez':new_value=new_value.toFixed(2)+translate_unit;break;case'rotatex':new_value=new_value.toFixed(1)+'deg';break;case'rotatey':new_value=new_value.toFixed(1)+'deg';break;case'rotatez':new_value=new_value.toFixed(1)+'deg';break;case'scale':new_value=new_value.toFixed(3);break;default:break;}
return new_value;}
_this.update_viewport_position=function()
{_this.viewport_top=$window.scrollTop();_this.viewport_bottom=_this.viewport_top+_this.viewport_height;}
_this.update_elements_in_view=function()
{_this.elements_in_view=[];var elements_length=_this.elements.length;for(var i=0;i<elements_length;i++)
{if((_this.elements[i].bottom<_this.viewport_top)&&(_this.onetime[i]==true))
{if(_this.elements[i].effects[0].hideafter&&!_this.done_once[i]){_this.elements[i].element.css({'display':'none','visibility':'hidden'});}
_this.done_once[i]=true;}
if(_this.done_once[i]!=true){if((_this.elements[i].top<_this.viewport_bottom)&&(_this.elements[i].bottom>_this.viewport_top))
{_this.elements_in_view.push(_this.elements[i]);}}}}
_this.on_resize=function()
{_this.update_viewport();_this.update_element_heights();_this.update_viewport_position();_this.update_elements_in_view();_this.animate();}
_this.update_viewport=function()
{_this.body_height=$document.height();_this.viewport_height=$window.height();}
_this.update_element_heights=function()
{var elements_length=_this.elements.length;for(var i=0;i<elements_length;i++)
{var element_height=_this.elements[i].element.outerHeight();var position=_this.elements[i].element.offset();_this.elements[i].height=element_height;_this.elements[i].top=position.top;_this.elements[i].bottom=position.top+element_height;}}
_this.find_only_once_elements=function()
{var elements_length=_this.elements.length;for(var i=0;i<elements_length;i++)
{_this.onetime[i]=_this.elements[i].element.hasClass('onceOnly')}}
$document.one(_this.init_events.join(' '),function(){_this.init();});return _this;})(jQuery);

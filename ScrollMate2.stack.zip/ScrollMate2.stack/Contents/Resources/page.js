
$(function(){function isTouchDevice(){return true==("ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch)}
$('html').addClass('bwd-js')
if(isTouchDevice()){$('html').addClass('bwd-touch')}});

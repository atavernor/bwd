
document.addEventListener("DOMContentLoaded",function(){var parent=$('#%parentId%.spl-lightbox');parent.find('>.spl-instances').append('<div class="lightbox-info menu-action" data-ma-cc="%id=cclass%" data-ma-link="%id=link -href%" %id=target% data-ll-name="%id=navName%" data-ll-trigger="ma_%id%"> </div>');});

 $(function(){$('#%parentId%').attr('data-trans','%id=transtime%');});

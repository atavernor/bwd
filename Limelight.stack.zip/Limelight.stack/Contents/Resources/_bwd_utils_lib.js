 function bwd_init(){document.documentElement.className+=" bwd-js";if("ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch){document.documentElement.className+=" bwd-touch";}}
if(document.readyState!=='loading'){bwd_init();}else{document.addEventListener('DOMContentLoaded',bwd_init)}

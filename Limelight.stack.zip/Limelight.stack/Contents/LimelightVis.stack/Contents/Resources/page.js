
window.onmessage=function(e){if(e.data=='limelightParent'){$('body').addClass('limelight-child');}}
$(function(){$('.limelight-vis').removeClass('preload');});

 $(function(){$('#%parentId%>.s-pro').closest('.stacks_out').addClass('sec-static-%id%');});

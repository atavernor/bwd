
$(document).ready(function(){var stack=$('#%parentId%'),menu=document.getElementById('menu_%parentId%'),panel=$('.side-panel',stack),snProChilds=$('.com_bigwhiteduck_stacks_sidenavpro_stack',stack),closeOnClick=%id=closeOnClick%,closeOnClickExcludeAttr='aria-expanded',closeOnClickExcludeClass='%id=launchID%'||'exclude',facetExcludeClass='facet-exclude',lowerBreakpoint=%id=breakpoints[0]%,upperBreakpoint=%id=breakpoints[1]%,facetWrap=$('.facet-wrapper',stack),toggle=$('.menu-link',stack),toggleIcon=$('.toggle_%id%'),menuZone=$('.mz_%id%'),trans_selectors=$('body, #menu_%parentId%');parentStack=stack.parent(),isInSticky=parentStack.parent().hasClass('sticky-grum')?true:false,parentCol=parentStack.closest($('.equalizer')),parentPillar=parentStack.closest('.stacks_in').parent().closest('.stacks_in');if(!isInSticky){if(!parentStack.parent().parent().hasClass('com_bigwhiteduck_stacks_pin_stack')){stack.parent().parent().wrap('<div class="nav-carrier_%parentId%"></div>');isInSticky=true;}}
function processExtraZone(){if(toggleIcon.hasClass('toggle-bar')){if(toggleIcon.hasClass('oc-left')){menuZone.insertAfter(toggle);}
if(toggleIcon.hasClass('oc-right')){menuZone.insertBefore(toggle);}}else{menuZone.remove();}}
function isInStickyG(){return stack.parent().parent().hasClass('sticky-grum')?true:false;}
function isInPillarCol(){return parentStack.closest('.stacks_in').parent().closest('.stacks_in').hasClass('com_joeworkman_stacks_foundation_pillar_stack')?true:false;}
function shiftSideNav(target){stack.appendTo(target);}
function applyTransition(state){trans_selectors.addClass('oc-trans');trans_selectors.on('transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd',function(){trans_selectors.removeClass('oc-trans');if(!$('body').hasClass('doc-open')){panel.removeClass('is-open').removeClass('is-closing');toggleIcon.removeClass('is-open');}});}
function modalOverflow(){var
win=$(window).height();panel.css('height',win);}
function isInBPRange(){var win=$(window).width();if(win>lowerBreakpoint&&win<upperBreakpoint){return true;}else{return false;}}
function sideBarRespond(){if(isInBPRange()){toggle.show();$('#menu_%parentId%',stack).addClass('is-toggle');stack.addClass('facet-active');snProChilds.addClass('facet-active');if(isInSticky&!isInPillarCol){shiftSideNav(parentCol);}else{if(isInPillarCol){shiftSideNav(parentPillar);}}
facetWrap.appendTo('#menu_%parentId%',stack);}else{if($('body').hasClass('%parentId%-duckslide-open')){toggleClose();}
toggle.hide();$('#menu_%parentId%',stack).removeClass('is-toggle');stack.removeClass('facet-active');snProChilds.removeClass('facet-active');if(isInSticky&&!isInStickyG()){stack.appendTo(parentStack).attr('style','');}
facetWrap.appendTo(stack);stack.attr('style','');}}
processExtraZone();$(window).resize(function(){sideBarRespond();});function toggleClose(){panel.removeClass('activated').addClass('is-closing');toggleIcon.addClass('is-closing');$('body').removeClass('%parentId%-duckslide-open').removeClass('doc-open');applyTransition('closing');}
function toggleOpen(){$('body').addClass('%parentId%-duckslide-open').addClass('doc-open');panel.addClass('activated').addClass('is-open');toggleIcon.addClass('is-open');}
function toggleMenu(){if(!isInBPRange())return;if($('body').hasClass('%parentId%-duckslide-open')){toggleClose();}else{toggleOpen();}}
if(closeOnClick){$(document).on('click',function(e){if(!$(e.target).hasClass(facetExcludeClass)&&!$(e.target).hasClass(closeOnClickExcludeClass)&&!$(e.target).attr(closeOnClickExcludeAttr)&&!$(e.target).parents().andSelf().is(toggle)&&menuIsOpen()){toggleClose();}});}
toggle.click(function(e){toggleMenu();e.preventDefault();});$('.modal-close',stack).click(function(e){toggleClose();e.preventDefault();});%[if %("%id=launchID%"!="")%]%$('.%id=launchID%.facet-toggle').click(function(e){toggleMenu();e.preventDefault();});$('.%id=launchID%.facet-hover').hoverIntent({over:toggleOpen});%[endif]%});

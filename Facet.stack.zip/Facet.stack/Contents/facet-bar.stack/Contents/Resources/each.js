
$(document).ready(function(){var
thisMenu=$('#menu_%parentId%',stack),toggleBar=$('.toggle_%id%'),toggleLink=$('#link_%id%'),toggleText=$('.toggle-text',toggleBar),menuZone=$('.mz_%id%'),title=$('.main-title',toggleBar),launchID='%id=launchID%',lowerBreakpoint=%id=breakpoints[0]%,upperBreakpoint=%id=breakpoints[1]%,zoneMiddle='%id=zonePos%'=='zone-middle'?true:false,trans_selectors=$('body, #menu_%parentId%'),isInScrollUpPro=toggleBar.parents('.su-content').length!=0?true:false;padBody();processExtraZone();function padBody(){if(toggleBar.css('display')=='none'){$('body').removeClass('f-facetbar-fixed');}else{$('body').addClass('f-facetbar-fixed');}}
function processExtraZone(){if(toggleBar.hasClass('toggle-bar')){if(toggleBar.hasClass('oc-left')){if(zoneMiddle){menuZone.insertAfter(title);}else{menuZone.insertBefore(toggleLink);}}
if(toggleBar.hasClass('oc-right')){if(zoneMiddle){menuZone.insertAfter(toggleLink);}else{menuZone.insertBefore(title);}}}else{menuZone.remove();}}
var resizeTimer;$(window).on('resize',function(e){clearTimeout(resizeTimer);resizeTimer=setTimeout(function(){padBody();},10);});});

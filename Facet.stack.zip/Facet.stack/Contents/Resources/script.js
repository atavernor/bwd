
$(document).ready(function(){var stack=$('#%id%');stack.addClass('%id=bgRespond% %id=bgStyle% %id=bgColOnMob%  %id=useMobColors% %[if %("%id=bgStyle%" == "bg-gradient")%]% %id=gradientType% %[endif]% %id=bgSize% %id=customClass%');});

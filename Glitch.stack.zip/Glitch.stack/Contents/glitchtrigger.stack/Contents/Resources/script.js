 $(function(){inView('.glitch-inview').on('enter',el=>{el.classList.add('on-always')}).on('exit',el=>{el.classList.remove('on-always')});});

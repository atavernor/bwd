
$(document).ready(function(){var stack=$('#post_proc_%id%'),blogPost=$('.com_joeworkman_stacks_totalcms_blog_post_stack>.post .post-content');$('pre',blogPost).each(function(){var thispre=$(this).text();console.error(thispre);var html=$.parseHTML(thispre);console.error(html);thispre.append(html);});});

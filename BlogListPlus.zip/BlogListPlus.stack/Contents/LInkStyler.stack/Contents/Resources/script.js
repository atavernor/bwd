
$(document).ready(function(){function getQuery(name,url){if(!url)url=window.location.href;name=name.replace(/[\[\]]/g,"\\$&");var regex=new RegExp("[?&]"+name+"(=([^&#]*)|&|#|$)"),results=regex.exec(url);if(!results)return null;if(!results[2])return'';return decodeURIComponent(results[2].replace(/\+/g," "));}
var allPostsActive=function(){$('ul.total-blog-links>li:first-child',stack).addClass('active-link');}
function processFilters(filter_type){var stack=$('#linkstyles_%id%'),filter=getQuery(filter_type);var links=$('ul.total-blog-links',stack);$('li',links).each(function(i){var thatli=$(this),thatHref=$('>a',thatli).attr('href');if(thatHref=='./'&&filter==null){noneactive=true;return false;}else{noneactive=false;}
switch(filter_type){case'category':var re=/.*?(&|\?category=)([^&]+).*/;break;case'tag':var re=/.*?(&|\?tag=)([^&]+).*/;break;}
var thatFilter;if((thatFilter=re.exec(thatHref))!==null){if(thatFilter.index===re.lastIndex){re.lastIndex++;}
if(thatFilter[2]==filter){thatli.addClass('active-link');}}});}
var stack=$('#linkstyles_%id%');var noneactive=false;%[if %id=include[0]%]%processFilters('category');%[endif]%%[if %id=include[1]%]%processFilters('tag');%[endif]%if(noneactive){allPostsActive()};});

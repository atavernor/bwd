
window.onmessage=function(e){if(e.data=='snatchboxParent'){$('body').addClass('snatchbox-child');}}

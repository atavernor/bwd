
(function(window,factory){if(typeof define==='function'&&define.amd){define(['jquery'],function($){return factory(window,$);})}else if(typeof module==='object'&&typeof module.exports==='object'){module.exports=factory(window,require('jquery'));}else{window.snatchbox=factory(window,window.jQuery||window.Zepto);}}(typeof window!=="undefined"?window:this,function(window,$){'use strict';var document=window.document;var $=stacks.jQuery;var _win=$(window);var _html=$('html');var _snatchbox_count=0;var _defaultHandlers={iframe:blogpostHandler};var _defaultOptions={esc:true,handler:null,gallery:false,template:'<div class="snatchbox" tabindex="-1"><div class="snatchbox-modal" data-snatchbox-close><div class="snatchbox-loader"><span class="loader-message">Loading...</div></span><div class="snatchbox-wrapper"><div class="snatchbox-content"></div><button class="snatchbox-close" type="button" title="Close (Esc)" data-snatchbox-close>&#10005;</button><div class="snatchbox-nav snatchbox-prev">&#10096;</div><div class="snatchbox-nav snatchbox-next">&#10097</div></div></div></div>',postlist:false,menu:false};function isMobile(){return"ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch;}
function boxCountToggle(){_html[_snatchbox_count>0?'addClass':'removeClass']('snatchbox-active');}
var transitionEndEvent=(function(){var el=document.createElement('div');var transEndEventNames={WebkitTransition:'webkitTransitionEnd',MozTransition:'transitionend',OTransition:'oTransitionEnd otransitionend',transition:'transitionend'};for(var name in transEndEventNames){if(el.style[name]!==undefined){return transEndEventNames[name];}}
return false;})();function transitionEnd(element){var deferred=$.Deferred();if(!transitionEndEvent){deferred.resolve();}else{element.one(transitionEndEvent,deferred.resolve);setTimeout(deferred.resolve,500);}
return deferred.promise();}
function settings(currSettings,key,value){if(arguments.length===1){return $.extend({},currSettings);}
if(typeof key==='string'){if(typeof value==='undefined'){return typeof currSettings[key]==='undefined'?null:currSettings[key];}
currSettings[key]=value;}else{$.extend(currSettings,key);}
return this;}
function blogpostHandler(target){return'<div class="snatchbox-post-container"><iframe frameborder="0" allowfullscreen src="'+target+'" name="'+Date.now()+'"></iframe></div>';}
function snatchbox(options){var _options={},_handlers={},_thisboxinstance,_caller,_current,_total,_stack,_next,_prev,_content,_ready=$.Deferred().resolve();function keyup(e){if(e.keyCode===27){close();}}
function resize(){var height=document.documentElement.clientHeight?document.documentElement.clientHeight:Math.round(_win.height());_content.css('max-height',Math.floor(height)+'px').trigger('snatchbox:resize',[_thisboxinstance]);}
function ready(el,content){if(!_thisboxinstance){return;}
_caller=el;_current=el.data('postindex');_total=$(el).closest('[data-post-monitor]').attr('data-postcount');_stack=$(el).closest('.snatchbox-stack');_content=$(content);_next=_thisboxinstance.find('.snatchbox-next');_prev=_thisboxinstance.find('.snatchbox-prev');_win.on('resize',resize);resize();updateNav(_current,_total);_thisboxinstance.find('.snatchbox-content').empty().append(_content).prepend($(options.postlist)).append($(options.menu));_content.removeClass('snatchbox-hide').trigger('snatchbox:ready',[_thisboxinstance,el]);$('.snatchbox-post-container>iframe').load(function(){_thisboxinstance.removeClass('snatchbox-framechange').removeClass('snatchbox-loading');$('.snatchbox-post-container>iframe')[0].contentWindow.postMessage('snatchboxParent','*');});_ready.resolve();}
function init(handler,content,options,el){_ready=$.Deferred();_snatchbox_count++;boxCountToggle();_thisboxinstance=$(options.template).addClass('snatchbox-loading').appendTo('body');if(isMobile()){_thisboxinstance.addClass('snatchbox-touch');}
if(options.postlist){_thisboxinstance.on('click','.snatchbox-all-posts',function(e){togglePostList();})}
if(!!options.esc){_win.on('keyup',keyup);}
if(!!options.gallery){_thisboxinstance.on('click','[data-snatchbox-nav]',function(e){var direction=$(this)[0].hasAttribute('data-snatchbox-next')?'next':'prev';postnav(direction);})}else{_thisboxinstance.addClass('no-nav');}
_thisboxinstance.on('click','[data-snatchbox-pagechange]',function(e){var uri=$(this).attr('data-snatchbox-uri');togglePostList();reloadframe(uri);})
setTimeout(function(){_thisboxinstance.addClass('snatchbox-is-open snatchbox-'+handler).on('click','[data-snatchbox-close]',function(e){if($(e.target).is('[data-snatchbox-close]')){close();}}).trigger('snatchbox:open',[_thisboxinstance,el]);$.when(content).always($.proxy(ready,null,el));},0);}
function open(target,options,el){var handler,content,handlers=$.extend({},_defaultHandlers,_handlers);options=$.extend({},_defaultOptions,_options,options);var call=function(name,callback){if(!callback){return true;}
content=callback(target,showbox);if(!!content){handler=name;return false;}};$.each(handlers,call);if(content){$.when(close()).done($.proxy(init,null,handler,content,options,el));}
return!!content;}
function updateNav(slide,totalslides){if(slide==totalslides){_thisboxinstance.addClass('last-post');}else{_thisboxinstance.removeClass('last-post');}
if(slide==1){_thisboxinstance.addClass('first-post');}else{_thisboxinstance.removeClass('first-post');}}
function reloadframe(uri){_thisboxinstance.addClass('snatchbox-framechange');$('.snatchbox-post-container>iframe').attr('src',uri).attr('name',Date.now());}
function postnav(direction){var upcoming=_current;if(direction==='next'&&_current<_total){upcoming++;}
if(direction==='prev'&&_current>1){upcoming--;}
if(upcoming==_current){return false;}else{_current=upcoming;}
updateNav(_current,_total);var newframe='[data-snatchbox][data-postindex="'+upcoming+'"]';var uri=$(newframe,_stack).data('snatchbox-target');reloadframe(uri);}
function togglePostList(){$('.snatchbox-post-container, .snatchbox-postlist-wrap, .snatchbox-all-posts',_thisboxinstance).toggleClass('apmenu-active');}
function close(){if(!_thisboxinstance){return;}
var deferred=$.Deferred();_ready.done(function(){_snatchbox_count--;boxCountToggle();_win.off('resize',resize).off('keyup',keyup);_content.trigger('snatchbox:close',[_thisboxinstance]);_thisboxinstance.removeClass('snatchbox-is-open').addClass('snatchbox-closed');$('.snatchbox-post-container,.snatchbox-postlist-wrap, .snatchbox-all-posts',_thisboxinstance).removeClass('apmenu-active');var thisboxinstance=_thisboxinstance,content=_content;_thisboxinstance=null;_content=null;transitionEnd(content.add(thisboxinstance)).always(function(){content.trigger('snatchbox:remove',[thisboxinstance]);thisboxinstance.remove();deferred.resolve();});});return deferred.promise();}
function showbox(event){if(!event.preventDefault){return showbox.open(event);}
var el=$(this);var target=el.data('snatchbox-target')||el.attr('href')||el.attr('src');if(!target){return;}
var options=el.data('snatchbox-options')||el.data('snatchbox');if(open(target,options,el)){el.blur();event.preventDefault();}}
showbox.handlers=$.proxy(settings,showbox,_handlers);showbox.options=$.proxy(settings,showbox,_options);showbox.open=function(target,options,el){open(target,options,el);return showbox;};showbox.close=function(){close();return showbox;};return showbox.options(options);}
snatchbox.version='1.0.0';snatchbox.handlers=$.proxy(settings,snatchbox,_defaultHandlers);snatchbox.options=$.proxy(settings,snatchbox,_defaultOptions);return snatchbox;}));

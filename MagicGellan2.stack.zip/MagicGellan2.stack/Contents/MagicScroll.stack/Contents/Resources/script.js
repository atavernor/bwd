
var autoscroll=false,automarker='';$(function(){if(window.location.hash){automarker=location.hash.replace('#','');window.location.hash="";autoscroll=true;}
var stack=$('#%id%'),scrollLinks=$('.magic-scroll-items',stack),generateMenu=function(){var i=0;$('[data-magellan-destination]').each(function(){var destination=$(this).data('magellan-destination'),magicZOrigin=$(this).data('magic-zone-origin'),item='<li class="mag-scroll-item">';if(typeof magicZOrigin!="undefined"){return true;}else{scrollLinks.append($(item).attr('data-magellan-arrival',destination).append($('<a class ="mag-scroll-link">').attr('href',('#'+destination))));}
i++;});},numMarkers=generateMenu();});$(window).load(function(){setTimeout(function(){try{foundation&&foundation.jQuery
var f=foundation.jQuery;f(document).foundation('magellan','reflow');}
catch(e){console.log('Foundation not found');}},100);if(autoscroll){$('.mag-scroll-item[data-magellan-arrival="'+automarker+'"]>a').trigger('click');}});

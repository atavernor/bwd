
document.addEventListener("DOMContentLoaded",function(){setTimeout(()=>{popCardsStack=$('[data-popcards-id="%id=cardsID%"]');$('#search-%id%').hideseek({list:'[data-popcards-id="%id=cardsID%"]',nodata:'%id=noCardText%',attribute:'text',highlight:true,ignore:'.filter-hide',reset_search:'.reset-search',headers:'',navigation:false,ignore_accents:false,hidden_mode:false,min_chars:1});var closeCards=function(cardSet){if(cardSet.length){cardSet.removeClass('card-open');$('.pop-card__body',cardSet).css('display','none');popCardsStack.removeClass('cards-open');}}
var openCards=function(cardSet){if(cardSet.length){cardSet.addClass('card-open');$('.pop-card__body',cardSet).css('display','block');popCardsStack.addClass('cards-open');}}
$(document).on('keyup',function(evt){if(!$('#search-%id%').is(':focus'))return false
if(evt.keyCode==27){$('.reset-search').trigger('click');closeCards($('.pop-card:not(.filter-hide)',popCardsStack));}
if(evt.keyCode==13){openCards($('.pop-card:not(.hidden-by-search):not(.filter-hide)',popCardsStack));}});},%id=delay%);});

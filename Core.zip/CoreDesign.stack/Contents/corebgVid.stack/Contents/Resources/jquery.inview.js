
(function($){'use strict';function getScrollTop(){return window.pageYOffset||document.documentElement.scrollTop||document.body.scrollTop;}
function getViewportHeight(){var height=window.innerHeight;if(height){return height;}
var mode=document.compatMode;if((mode||!$.support.boxModel)){height=(mode==='CSS1Compat')?document.documentElement.clientHeight:document.body.clientHeight;}
return height;}
function offsetTop(debug){var curtop=0;for(var obj=debug;obj;obj=obj.offsetParent){curtop+=obj.offsetTop;}
return curtop;}
function checkInView(){var viewportTop=getScrollTop(),viewportBottom=viewportTop+getViewportHeight();$('.inview').each(function(){var $el=$(this),elTop=offsetTop(this),elHeight=$el.height(),elBottom=elTop+elHeight,wasInView=$el.data('inview')||false,offset=$el.data('offset')||0,inView=elTop>=viewportTop&&elBottom<=viewportBottom,isBottomVisible=elBottom+offset>=viewportTop&&elTop<=viewportTop,isTopVisible=elTop-offset<=viewportBottom&&elBottom>=viewportBottom,inViewWithOffset=inView||isBottomVisible||isTopVisible||(elTop<=viewportTop&&elBottom>=viewportBottom);if(inViewWithOffset){var visPart=(isTopVisible)?'top':(isBottomVisible)?'bottom':'both';if(!wasInView||wasInView!==visPart){$el.data('inview',visPart);$el.trigger('inview',[true,visPart]);}}else if(!inView&&wasInView){$el.data('inview',false);$el.trigger('inview',[false]);}});}
function createFunctionLimitedToOneExecutionPerDelay(fn,delay){var shouldRun=false;var timer=null;function runOncePerDelay(){if(timer!==null){shouldRun=true;return;}
shouldRun=false;fn();timer=setTimeout(function(){timer=null;if(shouldRun){runOncePerDelay();}},delay);}
return runOncePerDelay;}
var runner=createFunctionLimitedToOneExecutionPerDelay(checkInView,100);$(window).on('checkInView.inview click.inview ready.inview scroll.inview resize.inview',runner);})(jQuery);

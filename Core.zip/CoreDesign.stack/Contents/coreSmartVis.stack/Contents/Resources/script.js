
$(function(){var
parent=document.getElementById('%parentId%'),cssTarget=document.querySelectorAll('.%id=cClass%:not(.enter-classname)');%[if %("%id=hideWhen%"=="session")%]%var key='key_%id%';%%[[if preview]]%%%[if %id=clearForPreview%]%localStorage.removeItem(key);return false;%[endif]%%%[[endif]]%%if(localStorage.getItem(key)=="viewed"){console.log('Item hidden by SmartVis %id%');if(parent||parent.nodeType==1){parent.style.display="none";}
if(cssTarget.length){for(i=0;i<cssTarget.length;i++){cssTarget[i].style.display="none";}}}else{localStorage.setItem(key,'viewed');}%[endif]%%[if %("%id=hideWhen%"=="scroll")%]%inView('#%parentId%,.%id=cClass%:not(.enter-classname)').on('exit',function(el){el.style.display="none";console.log('out of view');})%[endif]%});

 document.addEventListener('DOMContentLoaded',function(){var cc_%id%=new CoreContentCtrl({el:document.getElementById('%parentId%'),depad:%id=depad%});cc_%id%.init();});


var CoreContentCtrl=(function(){'use strict';var Constructor=function(o){if(!o.el){throw new Error('Core Content Control: Element has been removed by 3rd party php');}
const el=o.el;var api={};var co=function(e){e.classList.remove('cc-overflow');if(e.clientHeight<e.scrollHeight){e.classList.add('cc-overflow');}};api.init=function(){el.classList.add('cc-active');if(o.depad)el.classList.add('cc-depad');co(el);window.addEventListener("resize",()=>{co(el)});window.addEventListener("load",()=>{setTimeout(co(el),150);});};return api;};return Constructor;})();

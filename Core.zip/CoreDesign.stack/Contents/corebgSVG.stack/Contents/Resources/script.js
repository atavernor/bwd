 document.addEventListener('DOMContentLoaded',function(){CoreJS.chkSupports('%id=svgFit%','layer-%id%','%id=svgAlign%');});

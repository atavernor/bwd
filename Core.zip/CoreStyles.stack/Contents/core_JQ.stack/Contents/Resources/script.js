 const script=document.createElement("script");script.type="text/javascript";script.innerHTML="$=stacks.jQuery;";document.head.appendChild(script);

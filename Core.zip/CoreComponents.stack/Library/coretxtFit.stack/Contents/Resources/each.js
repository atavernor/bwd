
document.addEventListener("DOMContentLoaded",function(){fitty('#%parentId%, .%id=cClass%:not(.enter-classname),.%id=features%:not(.none)',{minSize:%id=limits[0]%,maxSize:%id=limits[1]%,multiLine:%id=multiLine%,});});fitty.observeWindow=true;fitty.observeWindowDelay=10;

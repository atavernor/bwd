
document.addEventListener('DOMContentLoaded',function(){var targets=%("%id=claxID%"!="")%?'.clax.%id=claxID%':'.clax',clax=new Clax(targets,{speed:%id=speed%,center:%id=useCenter%,zeroPoint:%id=zeroPoint%,wrapper:%id=customWrapper%?'%id=wrapperEl%':null});%[if %id=useBP%]%var timeout;function widthResize(mq){if(!timeout){timeout=setTimeout(function(){timeout=null;if(mq.matches){clax.refresh();}else{clax.destroy();}},66);}}
const mq=window.matchMedia("(min-width: %id=bp%px)");mq.addListener(widthResize);widthResize(mq);%[endif]%});

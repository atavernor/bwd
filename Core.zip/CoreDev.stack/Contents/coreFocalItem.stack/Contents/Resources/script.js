
document.addEventListener('DOMContentLoaded',function(){const features=document.querySelectorAll('.core-focal');observer=new IntersectionObserver(sections=>{sections.forEach(section=>{console.log(section)
if(section.intersectionRatio>0.4){section.target.classList.add('show-feature');}else{section.target.classList.remove('show-feature');}});},{threshold:0.4});if('IntersectionObserver'in window){document.documentElement.classList.add('no-iobs');}
document.documentElement.classList.add('core-iobs');features.forEach(feature=>observer.observe(feature));});

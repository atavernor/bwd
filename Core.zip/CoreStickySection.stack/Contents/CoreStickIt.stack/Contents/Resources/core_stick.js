
(function(){var win;win=$(window);doc=$(document);scroll_container=win;$.fn.coreStick=function(opts){var doc,core_sticky,does_bottom_out,fn,i,inner_scrolling,len,manual_spacer,offset_top,outer_width,parent_selector,container,recalc_every,sticky_class;if(opts==null){opts={};}
sticky_class=opts.sticky_class,inner_scrolling=opts.inner_scrolling,recalc_every=opts.recalc_every,parent_selector=opts.parent,offset_top=opts.offset_top,manual_spacer=opts.spacer,does_bottom_out=opts.push_on_bottom;if(offset_top==null){offset_top=0;}
if(parent_selector==null){parent_selector=void 0;}
if(inner_scrolling==null){inner_scrolling=true;}
if(sticky_class==null){sticky_class="core-stuck";}
doc=$(document);if(does_bottom_out==null){does_bottom_out=true;}
if(container!=null){scroll_container=$(container);}
outer_width=function(el){var _el,computed,w;if(window.getComputedStyle){_el=el[0];computed=window.getComputedStyle(el[0]);w=parseFloat(computed.getPropertyValue("width"))+parseFloat(computed.getPropertyValue("margin-left"))+parseFloat(computed.getPropertyValue("margin-right"));if(computed.getPropertyValue("box-sizing")!=="border-box"){w+=parseFloat(computed.getPropertyValue("border-left-width"))+parseFloat(computed.getPropertyValue("border-right-width"))+parseFloat(computed.getPropertyValue("padding-left"))+parseFloat(computed.getPropertyValue("padding-right"));}
return w;}else{return el.outerWidth(true);}};fn=function(core_sticky,padding_bottom,parent_top,parent_height,top,height,el_float,detached){var bottomed,detach,fixed,last_pos,last_scroll_height,offset,parent,recalc,sticky_recalc,recalc_counter,spacer,tick;if(core_sticky.data("coreSticky")){return;}
core_sticky.data("coreSticky",true);last_scroll_height=doc.height();parent=core_sticky.parent();if(parent_selector!=null){parent=parent.closest(parent_selector);}
if(!parent.length){console.error("SG: Failed to find parent container :",parent);}
fixed=false;bottomed=false;spacer=manual_spacer!=null?manual_spacer&&core_sticky.closest(manual_spacer):$("<div />");if(spacer){spacer.css('position',core_sticky.css('position'));}
recalc=function(){var border_top,padding_top,restore;if(detached){return;}
win_height=win.height();doc_height=doc.height();last_scroll_height=doc.height();border_top=parseInt(parent.css("border-top-width"),10);padding_top=parseInt(parent.css("padding-top"),10);padding_bottom=parseInt(parent.css("padding-bottom"),10);if(container!=null){parent_top=parent.offset().top+border_top+padding_top;}else{parent_top=parent.offset().top+border_top+padding_top+scroll_container.scrollTop();}
parent_height=parent.height();if(fixed){fixed=false;bottomed=false;if(manual_spacer==null){core_sticky.insertAfter(spacer);spacer.detach();}
core_sticky.css({position:"",top:"",width:"",bottom:""}).removeClass(sticky_class);restore=true;}
if(container!=null){top=core_sticky.offset().top-(parseInt(core_sticky.css("margin-top"),10)||0)-offset_top;}else{top=core_sticky.offset().top-(parseInt(core_sticky.css("margin-top"),10)||0)-offset_top+scroll_container.scrollTop();}
height=core_sticky.outerHeight(true);el_float=core_sticky.css("float");if(spacer){spacer.css({width:outer_width(core_sticky),height:height,display:core_sticky.css("display"),"vertical-align":core_sticky.css("vertical-align"),"float":el_float});}
if(restore){return tick();}};recalc();if(height===parent_height){core_sticky.addClass('no-height-to-stick');$('body').addClass('core-no-stick');console.log('HEIGHT === parent height: Cannot Stick');console.log('Core Sticky:',core_sticky,'parent: ',parent);return;}else{core_sticky.removeClass('no-height-to-stick');$('body').removeClass('core-no-stick');}
last_pos=void 0;offset=offset_top;recalc_counter=recalc_every;tick=function(){var css,delta,recalced,scroll,will_bottom,win_height;if(detached){return;}
recalced=false;if(recalc_counter!=null){recalc_counter-=1;if(recalc_counter<=0){recalc_counter=recalc_every;recalc();recalced=true;}}
if(!recalced&&doc_height!==last_scroll_height){recalc();recalced=true;}
scroll=scroll_container.scrollTop();if(last_pos!=null){delta=scroll-last_pos;}
last_pos=scroll;if(fixed){if(does_bottom_out){will_bottom=scroll+height+offset>parent_height+parent_top;if(bottomed&&!will_bottom){bottomed=false;core_sticky.css({position:"fixed",bottom:"",top:offset}).trigger("coreSticky:unbottom");}}
if(scroll<=top){fixed=false;offset=offset_top;if(manual_spacer==null){if(el_float==="left"||el_float==="right"){core_sticky.insertAfter(spacer);}
spacer.detach();}
css={position:"",width:"",top:""};core_sticky.css(css).removeClass(sticky_class).trigger("coreSticky:unstick");}
if(inner_scrolling){if(height+offset_top>win_height){if(!bottomed){offset-=delta;offset=Math.max(win_height-height,offset);offset=Math.min(offset_top,offset);if(fixed){core_sticky.css({top:offset+"px"});}}}}}else{if(scroll>top){fixed=true;css={position:"fixed",top:offset};css.width=core_sticky.css("box-sizing")==="border-box"?core_sticky.outerWidth()+"px":core_sticky.width()+"px";core_sticky.css(css).addClass(sticky_class);if(manual_spacer==null){core_sticky.after(spacer);if(el_float==="left"||el_float==="right"){spacer.append(core_sticky);}}
core_sticky.trigger("coreSticky:stick");}}
if(fixed&&does_bottom_out){if(will_bottom==null){will_bottom=scroll+height+offset>parent_height+parent_top;}
if(!bottomed&&will_bottom){bottomed=true;if(parent.css("position")==="static"){parent.css({position:"relative"});}
return core_sticky.css({position:"absolute",bottom:padding_bottom,top:"auto"}).trigger("coreSticky:bottom");}}};sticky_recalc=function(){recalc();return tick();};detach=function(){detached=true;scroll_container.off("touchmove",tick);scroll_container.off("scroll",tick);win.off("resize",sticky_recalc);$(document.body).off("coreSticky:recalc",sticky_recalc);core_sticky.off("coreSticky:detach",detach);core_sticky.removeData("coreSticky");core_sticky.css({position:"",bottom:"",top:"",width:""});parent.position("position","");if(fixed){if(manual_spacer==null){if(el_float==="left"||el_float==="right"){core_sticky.insertAfter(spacer);}
spacer.remove();}
return core_sticky.removeClass(sticky_class);}};scroll_container.on("touchmove",tick);scroll_container.on("scroll",tick);win.on("resize",sticky_recalc);$(document.body).on("coreSticky:recalc",sticky_recalc);core_sticky.on("coreSticky:detach",detach);return setTimeout(tick,0);};for(i=0,len=this.length;i<len;i++){core_sticky=this[i];fn($(core_sticky));}
return this;};}).call(this);

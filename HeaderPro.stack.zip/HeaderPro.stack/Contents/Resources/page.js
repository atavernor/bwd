 var elements=document.getElementsByClassName('hp-slice');while(elements.length>0){elements[0].parentNode.removeChild(elements[0]);}

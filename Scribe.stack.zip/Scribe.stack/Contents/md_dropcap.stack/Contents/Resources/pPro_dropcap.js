(function($){var CJKrx=/^\s*([^\uAC00-\uD7A3\u4E00-\u9FFF]?[\u00C0-\u02B8\uAC00-\uD7A3\u4E00-\u9FFF])(.*)/im;var ExtRx=/^\s*([^a-z0-9\u00C0-\u02B8]?[a-z0-9\u00C0-\u02B8])(.*)/im;var ASCIIrx=/^\s*(\W?[a-z0-9])(.*)/im;var UnifiedRx=/^\s*([^a-z0-9\u00C0-\u02B8\uAC00-\uD7A3\u4E00-\u9FFF]?[a-z0-9\u00C0-\u02B8\uAC00-\uD7A3\u4E00-\u9FFF])(.*)/im;var Mode={"ascii":ASCIIrx,"cjk":CJKrx,"extended":ExtRx,"unified":UnifiedRx};var dCSS={padding:"0px 3px 0px 0px",display:"block",textAlign:"right",float:"left",overflow:"visible",textDecoration:"none"};$.fn.dropJ=function(arg){var opts=$.extend({},$.fn.dropJ.defaults,arg);return this.each(function(){$this=$(this);var o=$.meta?$.extend({},opts,$this.data()):opts;if(_addDropCap($this.get(0),$this.get(0),o)&&o.clear)
{$this.css({clear:"left"});}});};$.fn.dropJ.defaults={"css":dCSS,"clear":true,"keepCase":true,"regex":Mode.ascii,"element":"span","factor":3,"toggleFamily":false,"class":"dropj"};function _addDropCap(c,n,o){var rx=Mode[o.mode]||Mode.ascii;if((n.nodeType==3)&&n.nodeValue.match(rx))
{var val=n.nodeValue;val=val.replace(/\n+/g," ");var capRemainder=val.match(rx);var capText=capRemainder?capRemainder[capRemainder.length-2]:'';var remainderText=capRemainder?capRemainder[capRemainder.length-1]:'';if(!o.keepCase)capText=capText.toUpperCase();var cap=document.createTextNode(capText);var remainder=document.createTextNode(remainderText);var dropCap=document.createElement(o["element"]);dropCap.appendChild(cap);n.parentNode.replaceChild(remainder,n);remainder.parentNode.insertBefore(dropCap,remainder);$(dropCap).css(o["css"]);$(dropCap).addClass(o["class"]);_setSpecialCSS(c,dropCap,o)
return dropCap;}
else if(n.nodeType==3)
{$(n).parent().css({float:"left",display:"inline"});}
for(var i=0;i<n.childNodes.length;i++)
{var dc=_addDropCap(c,n.childNodes[i],o);if(dc)return dc;}};function _setSpecialCSS(c,dc,o){var h=$(dc).css("lineHeight");if(o.factor==true)
{if(o.hang)
{var fs=($(c).height())+"px";var lh=($(c).height()*.9)+"px";$(dc).css({fontSize:fs,lineHeight:lh});_update_hang(dc);}
else
{var i=6;while(i--){if($(dc).height()>=$(c).height())break;if($(dc).width()>(.4*$(c).width()))break;var fs=($(c).height()*1.4)+"px";var lh=($(c).height()*1)+"px";$(dc).css({fontSize:fs,lineHeight:lh});}
var mb=(-1*$(dc).height()/9)+"px";$(dc).css({marginBottom:mb});}}
else if(h.substr(h.length-2,2)=="px")
{var px=h.substring(0,h.length-2);var mt="0px";var mb=(-1*Math.round(px/5))+"px";$(dc).css({marginTop:mt,marginBottom:mb});var fs=(o.factor*1.07*px)+"px";var lh=(o.factor*px*0.98)+"px";$(dc).css({fontSize:fs,lineHeight:lh});}
else
{var fs=(o.factor*1.05)+"em";$(dc).css({fontSize:fs});$(dc).css({margin:"-.1ex 0 -.25ex 0",lineHeight:"95%"});}
if(o.hang)_update_hang(dc);}
function _update_hang(dc){var m=(-1*$(dc).width())+"px";$(dc).css({marginLeft:m,marginRight:m});}})(jQuery);

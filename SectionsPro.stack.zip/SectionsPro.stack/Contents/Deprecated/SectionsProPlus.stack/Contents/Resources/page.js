
$(document).ready(function(){$('.s-pro').each(function(){var that=$(this),inner=$('>shear-wrapper>.shear-inner>.inner-content',that),innerwrap=$('.content-wrapper',inner);if(that.hasClass('sec-overflow')){that.parent().parent().addClass('section-overflow');}
if(inner.find('.impact-wrapper').length>0){innerwrap.addClass('fill-content');}});});


$(function(){var stack=$('#%parentId%'),hovTarget=$('.hov-target',stack);hovTarget.addClass('%id=hovType%');$(window).on('load',function(){hovTarget.addClass('%id=hovType%');})});

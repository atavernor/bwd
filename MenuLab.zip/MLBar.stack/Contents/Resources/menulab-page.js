
$(function(){$('div[class*="com_bigwhiteduck_stacks_menulab_"]').addClass('ml-flex-menu');$('html').addClass('js-menulab');var isMobile=function(){return"ontouchstart"in window||window.DocumentTouch&&document instanceof DocumentTouch;};if(isMobile()){$('html').addClass('bb-touch');}
$(window).on('load',function(){$('div[class*="com_bigwhiteduck_stacks_menulab_"]').addClass('ml-flex-menu');})});
